#include "app.h"
extern keypad_t keypad_1;
 uint8_t i = 0;
extern keypad_t keypad_1;
uint8_t key_val =255;
uint8_t flagin =0;
uint8_t pass[4]={5,5,5,5};
uint8_t check_pass[20];
uint8_t number_digit =0;
uint8_t number_of_users=2;
uint8_t index_of_user =0;
user_t users[2];
void app_init(void){
HLCD_INIT();
keypad_inti(&keypad_1);
key_val='\0';
strcpy(users[0].position,"Owner");
strcpy(users[0].name,"Alice");
 users[0].password[0] = 1;
    users[0].password[1] = 1;
    users[0].password[2] = 1;
    users[0].password[3] = 1;
strcpy(users[1].position,"Owner");
strcpy(users[1].name,"Omar");
 users[1].password[0] = 5;
    users[1].password[1] = 5;
    users[1].password[2] = 5;
    users[1].password[3] = 5;
}
uint8_t Cheack_Password(uint8_t* b,uint8_t n)
{
    if(number_digit<4||number_digit>4)return 0;
	uint8_t ret=0;
    for(uint8_t n=0 ;n <2;n++)
	{
        ret=0;
        for(uint8_t counter =0; counter<n-1;counter++)
	{
		if(users[n].password[counter] == b[counter])
		{
			ret++;
		}
	}

    if(ret == n-1){
        index_of_user=n;
        return 1;
        }
		
    }
		return 0;
}
void set_passward(){
     HLCD_voidCLRScreen();
      if(i==0)   {
        LCD_send_string_pos("PLEASE ENTER PASSWARD...",0,0);}
     else if(i>0){LCD_send_string_pos("PLEASE ENTER CORRECT PASSWARD...",0,0);}
  
     number_digit =0;
while(1){
    do {
        key_val=keypad_scan(&keypad_1);
    }while(key_val=='\0');
    if(key_val=='#')return;
    LCD_Send_Number_Pos(key_val,number_digit,1);
    _delay_ms(10);
     HLCD_voidGoToXy(number_digit,1);
    HLCD_send_DATA('*');
    check_pass[number_digit] = key_val;
    number_digit++;
}
}
void run_program(void){
    set_passward();
 HLCD_voidCLRScreen();
 LCD_send_string_pos(" LODING...",0,0);
 _delay_ms(100);
HLCD_voidCLRScreen();
i++;
    while(i<3)
   { 

    if(Cheack_Password(check_pass,4)){
        flagin=1;
        break;
    }
    i++;
    if(flagin==0){
    set_passward();
    HLCD_voidCLRScreen();
    LCD_send_string_pos(" LODING...",0,0);
    _delay_ms(100);
    }
    
    }
    if(flagin==1){
         i=0;
    HLCD_voidCLRScreen();
 LCD_send_string_pos(" LOGGIN... ",15,0);
 _delay_ms(100);
  HLCD_voidCLRScreen();
 LCD_send_string_pos(" YOUR POSITION IS... ",0,0);
 LCD_send_string_pos(&(users[index_of_user].position),1,1);
 _delay_ms(100);
  HLCD_voidCLRScreen();
 LCD_send_string_pos(" YOUR NAME IS... ",0,0);
 LCD_send_string_pos(&(users[index_of_user].name),1,1);
  _delay_ms(100);
  HLCD_voidCLRScreen();
 LCD_send_string_pos("THANK YOU... ",15,0);
 _delay_ms(100);
 HLCD_send_command(_LCD_DISPLAY_OFF_CURSOR_OFF );
 _delay_ms(50);
 }
 else if(flagin==0){
    i=0;
    HLCD_voidCLRScreen();
 LCD_send_string_pos(" PASSWARD FAILED... ",0,0);
 _delay_ms(50);
 HLCD_send_command(_LCD_DISPLAY_OFF_CURSOR_OFF );
  _delay_ms(200);
 }
}