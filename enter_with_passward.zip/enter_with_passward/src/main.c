#include "app.h"
int main(){
app_init();
int i=0;
while(1)
 {
   
    run_program();
 }
 return 0;
}


