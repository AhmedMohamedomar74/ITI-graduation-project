#include "app.h"
int main(){
   /*intialize the system*/
app_init();
int i=0;
while(1)
 {
   /*run my program for infinity */
    run_program();
 }
 return 0;
}


